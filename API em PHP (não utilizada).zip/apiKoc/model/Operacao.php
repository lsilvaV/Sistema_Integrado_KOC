<?php

class Operacao{
    private $con;

    function __construct()
    {
        require_once dirname(__FILE__). './Conexao.php';

        $bd = new Conexao();

        $this->con = $bd->connect();
    }

    //CLIENTE //CLIENTE //CLIENTE //CLIENTE
    function createCli($campo_2, $campo_3, $campo_4, $campo_5, $campo_6){
        $stmt = $this->con->prepare("INSERT INTO tbcliente (nomeCli, cpfCli, foneCli, emailCli, senhaCli) VALUES (?,?,?,?,?)");

        $stmt->bind_param("siiss", $campo_2, $campo_3, $campo_4, $campo_5, $campo_6);
            if($stmt->execute())
                return true;
            return var_dump($stmt);
    }

    function getCli(){
        $stmt = $this->con->prepare("SELECT * FROM tbcliente");
        $stmt->execute();
        $stmt->bind_result($idCli, $nomeCli, $cpfCli, $foneCli, $emailCli, $senhaCli);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['idCli'] = $idCli;
            $dica['nomeCli'] = $nomeCli;
            $dica['cpfCli'] = $cpfCli;
            $dica['foneCli'] = $foneCli;
            $dica['emailCli'] = $emailCli;
            $dica['senhaCli'] = $senhaCli;

            array_push($dicas,$dica);

        }
        return $dicas;
    }

    function updateCli($campo_1, $campo_2, $campo_3, $campo_4, $campo_5, $campo_6){
        $stmt = $this->con->prepare("UPDATE tbcliente SET nomeCli = ?, cpfCli = ?, foneCli = ?, emailCli = ?, senhaCli = ? WHERE idCli = ?");
        $stmt->bind_param("siissi", $campo_2, $campo_3, $campo_4, $campo_5, $campo_6, $campo_1);
        if($stmt -> execute())
            return true;
        return false;
    }
    

    function deleteCli($campo_1){
        $stmt = $this->con->prepare("DELETE FROM tbcliente WHERE idCli = ?");
        $stmt->bind_param("i",$campo_1);
        if($stmt->execute())
            return true;
        return false;
    }

    //FUNCIONÁRIO //FUNCIONÁRIO //FUNCIONÁRIO //FUNCIONÁRIO
    function createFun($campo_2, $campo_3, $campo_4){
        $stmt = $this->con->prepare("INSERT INTO tbfuncionario (nomeFun, cpfFun, foneFun) VALUES (?,?,?)");

        $stmt->bind_param("sii", $campo_2, $campo_3, $campo_4);
            if($stmt->execute())
                return true;
            return var_dump($stmt);
    }

    function getFun(){
        $stmt = $this->con->prepare("SELECT * FROM tbfuncionario");
        $stmt->execute();
        $stmt->bind_result($idFun, $nomeFun, $cpfFun, $foneFun);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['idFun'] = $idFun;
            $dica['nomeFun'] = $nomeFun;
            $dica['cpfFun'] = $cpfFun;
            $dica['foneFun'] = $foneFun;

            array_push($dicas,$dica);

        }
        return $dicas;
    }

    function updateFun($campo_1, $campo_2, $campo_3, $campo_4){
        $stmt = $this->con->prepare("UPDATE tbfuncionario SET nomeFun = ?, cpfFun = ?, foneFun = ? WHERE idFun = ?");
        $stmt->bind_param("siii", $campo_2, $campo_3, $campo_4, $campo_1);
        if($stmt -> execute())
            return true;
        return false;
    }

    function deleteFun($campo_1){
        $stmt = $this->con->prepare("DELETE FROM tbfuncionario WHERE idFun = ?");
        $stmt->bind_param("i",$campo_1);
        if($stmt->execute())
            return true;
        return false;
    }

    //PEDIDO //PEDIDO //PEDIDO //PEDIDO
    function createPed($campo_2, $campo_3, $campo_4, $campo_5, $campo_6, $campo_7){
        $stmt = $this->con->prepare("INSERT INTO tbpedido (configPed, dataEnPed, dataSaPed, statusPed, valorPed, idCliFK) VALUES (?,?,?,?,?,?)");

        $stmt->bind_param("ssssdi", $campo_2, $campo_3, $campo_4, $campo_5, $campo_6, $campo_7);
            if($stmt->execute())
                return true;
            return var_dump($stmt);
    }

    function getPed(){
        $stmt = $this->con->prepare("SELECT * FROM tbpedido");
        $stmt->execute();
        $stmt->bind_result($idPed, $configPed, $dataEnPed, $dataSaPed, $statusPed, $valorPed, $idCliFK);

        $dicas = array();

        while($stmt->fetch()){
            $dica = array();
            $dica['idPed'] = $idPed;
            $dica['configPed'] = $configPed;
            $dica['dataEnPed'] = $dataEnPed;
            $dica['dataSaPed'] = $dataSaPed;
            $dica['statusPed'] = $statusPed;
            $dica['valorPed'] = $valorPed;
            $dica['idCliFK'] = $idCliFK;

            array_push($dicas,$dica);

        }
        return $dicas;
    }

    function updatePed($campo_1, $campo_2, $campo_3, $campo_4, $campo_5, $campo_6, $campo_7){
        $stmt = $this->con->prepare("UPDATE tbpedido SET configPed = ?, dataEnPed = ?, dataSaPed = ?, statusPed = ?, valorPed = ?, idCliFK = ? WHERE idPed = ?");
        $stmt->bind_param("ssssdii", $campo_2, $campo_3, $campo_4, $campo_5, $campo_6, $campo_7, $campo_1);
        if($stmt -> execute())
            return true;
        return false;
    }

    function deletePed($campo_1){
        $stmt = $this->con->prepare("DELETE FROM tbpedido WHERE idPed = ?");
        $stmt->bind_param("i",$campo_1);
        if($stmt->execute())
            return true;
        return false;
    }
}
?>