<?php
    require_once('../model/Operacao.php');

    function isTheseParametersAvailable($params){
        $available = true;
        $missingParams="";

        foreach($params as $param){
            if(!isset($_POST[$param]) || strlen($_POST[$param]) <= 0){
                $available = false;
                $missingParams = $missingParams.", ".$param;
            }
        }

        if(!$available){
            $response = array();
            $response['error'] = true;
            $response['message'] = 'Parameters '.substr($missingParams, 1, strlen($missingParams)).' missing';
    
            echo json_encode($response);

            die();
            
        }
    }

    $response = array();
    
    if(isset($_GET['apicall'])){
        switch($_GET['apicall']){

            case 'createCli':
                isTheseParametersAvailable(array('campo_2', 'campo_3', 'campo_4', 'campo_5', 'campo_6'));

                $db = new Operacao();

                //CLIENTE //CLIENTE //CLIENTE //CLIENTE

                $result = $db->createCli(
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4'],
                    $_POST['campo_5'],
                    $_POST['campo_6']
                );

                if($result){
                    $response['error'] = false;
                    $response['message'] = 'Dados inseridos com sucesso.';
                    $response['dadosCriar'] = $db->getCli();

                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram inseridos';
                }
            break;

            case 'getCli':
                $db = new Operacao();
                $response['error'] = false;
                $response['message'] = 'Dados listados com sucesso.';
                $response['dadosListar']=$db->getCli();
            break;

            case 'updateCli':
                isTheseParametersAvailable(array('campo_1','campo_2','campo_3','campo_4', 'campo_5', 'campo_6'));
                
                $db = new Operacao();
                $result = $db->updateCli(
                    $_POST['campo_1'],
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4'],
                    $_POST['campo_5'],
                    $_POST['campo_6']
                );

                if($result){
                    $db = new Operacao();
                    $response['error'] = false;
                    $response['message'] = 'Dados alterados com sucesso.';
                    $response['dadosAlterar']=$db->getCli();

                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram alterados.';
                }
            break;

            case 'deleteCli':
                if(isset($_GET['idCli'])){
                    $db = new Operacao();
                    if($db->deleteCli($_GET['idCli'])){
                        $response['error'] = false;
                        $response['message'] = 'Dados apagados com sucesso.';
                        $response['deleteCli'] = $db->getCli();

                    }else{
                        $response['error'] = true;
                        $response['message'] = 'Algo deu errado.';
                    }
                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não apagados.';
                }
            break;

            //FUNCIONÁRIO //FUNCIONÁRIO //FUNCIONÁRIO //FUNCIONÁRIO

            case 'createFun':
                isTheseParametersAvailable(array('campo_2', 'campo_3', 'campo_4'));

                $db = new Operacao();

                $result = $db->createFun(
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4'],
                );

                if($result){
                    $response['error'] = false;
                    $response['message'] = 'Dados inseridos com sucesso.';
                    $response['dadosCriar'] = $db->getFun();

                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram inseridos';
                }
            break;

            case 'getFun':
                $db = new Operacao();
                $response['error'] = false;
                $response['message'] = 'Dados listados com sucesso.';
                $response['dadosListar']=$db->getFun();
            break;

            case 'updateFun':
                isTheseParametersAvailable(array('campo_1','campo_2','campo_3','campo_4'));
                
                $db = new Operacao();
                $result = $db->updateFun(
                    $_POST['campo_1'],
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4']
                );

                if($result){
                    $db = new Operacao();
                    $response['error'] = false;
                    $response['message'] = 'Dados alterados com sucesso.';
                    $response['dadosAlterar']=$db->getFun();
                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram alterados.';
                }
            break;

            case 'deleteFun':
                if(isset($_GET['idFun'])){
                    $db = new Operacao();
                    if($db->deleteFun($_GET['idFun'])){
                        $response['error'] = false;
                        $response['message'] = 'Dados apagados com sucesso.';
                        $response['deleteFun'] = $db->getFun();

                    }else{
                        $response['error'] = true;
                        $response['message'] = 'Algo deu errado.';
                    }
                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não apagados.';
                }
            break;

            //PEDIDO //PEDIDO //PEDIDO //PEDIDO

            case 'createPed':
                isTheseParametersAvailable(array('campo_2', 'campo_3', 'campo_4', 'campo_5', 'campo_6', 'campo_7'));

                $db = new Operacao();

                $result = $db->createPed(
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4'],
                    $_POST['campo_5'],
                    $_POST['campo_6'],
                    $_POST['campo_7']
                );

                if($result){
                    $response['error'] = false;
                    $response['message'] = 'Dados inseridos com sucesso.';
                    $response['dadosCriar'] = $db->getPed();

                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram inseridos';
                }
            break;

            case 'getPed':
                $db = new Operacao();
                $response['error'] = false;
                $response['message'] = 'Dados listados com sucesso.';
                $response['dadosListar']=$db->getPed();
            break;

            case 'updatePed':
                isTheseParametersAvailable(array('campo_1', 'campo_2', 'campo_3', 'campo_4', 'campo_5', 'campo_6', 'campo_7'));
                
                $db = new Operacao();
                $result = $db->updateFun(
                    $_POST['campo_1'],
                    $_POST['campo_2'],
                    $_POST['campo_3'],
                    $_POST['campo_4'],
                    $_POST['campo_5'],
                    $_POST['campo_6'],
                    $_POST['campo_7']
                );

                if($result){
                    $db = new Operacao();
                    $response['error'] = false;
                    $response['message'] = 'Dados alterados com sucesso.';
                    $response['dadosAlterar']=$db->getPed();
                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não foram alterados.';
                }
            break;

            case 'deletePed':
                if(isset($_GET['idPed'])){
                    $db = new Operacao();
                    if($db->deletePed($_GET['idPed'])){
                        $response['error'] = false;
                        $response['message'] = 'Dado apagado com sucesso.';
                        $response['deletePed'] = $db->getPed();

                    }else{
                        $response['error'] = true;
                        $response['message'] = 'Algo deu errado.';
                    }
                }else{
                    $response['error'] = true;
                    $response['message'] = 'Dados não apagados.';
                }
            break;
        }
    }else{

        $response['error'] = true;
        $response['message'] = 'Chamada de API com defeito.';
    }

    echo json_encode($response);
?>