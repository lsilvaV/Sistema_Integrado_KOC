-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2022 at 01:11 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbkoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbcliente`
--

CREATE TABLE `tbcliente` (
  `idCli` int(4) NOT NULL,
  `nomeCli` varchar(48) NOT NULL,
  `cpfCli` bigint(11) NOT NULL,
  `foneCli` bigint(11) NOT NULL,
  `emailCli` varchar(64) NOT NULL,
  `senhaCli` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbpedido`
--

CREATE TABLE `tbpedido` (
  `idPed` int(4) NOT NULL,
  `configPed` varchar(256) NOT NULL,
  `dataEnPed` varchar(11) NOT NULL,
  `dataSaPed` varchar(11) NOT NULL,
  `statusPed` varchar(64) NOT NULL,
  `valorPed` decimal(6,2) NOT NULL,
  `idCliFK` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbcliente`
--
ALTER TABLE `tbcliente`
  ADD PRIMARY KEY (`idCli`);

--
-- Indexes for table `tbpedido`
--
ALTER TABLE `tbpedido`
  ADD PRIMARY KEY (`idPed`),
  ADD KEY `rel_idCliFK_idCli` (`idCliFK`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbcliente`
--
ALTER TABLE `tbcliente`
  MODIFY `idCli` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbpedido`
--
ALTER TABLE `tbpedido`
  MODIFY `idPed` int(4) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbpedido`
--
ALTER TABLE `tbpedido`
  ADD CONSTRAINT `rel_idCliFK_idCli` FOREIGN KEY (`idCliFK`) REFERENCES `tbcliente` (`idCli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
